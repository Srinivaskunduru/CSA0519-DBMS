from datetime import datetime, date
from functools import wraps

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func

from models import (
    db, User, Movie, Genre, MovieGenre, Theatre, Screen, Seat, Show, ShowSeat,
    Booking, Payment,
)

admin_bp = Blueprint("admin", __name__)


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapped


@admin_bp.route("/admin")
@login_required
@admin_required
def dashboard():
    total_users = User.query.filter_by(is_admin=False).count()
    total_movies = Movie.query.count()
    total_theatres = Theatre.query.count()
    total_bookings = Booking.query.count()
    successful_payments = Payment.query.filter_by(status="Success").count()
    failed_payments = Payment.query.filter_by(status="Failed").count()
    total_revenue = db.session.query(func.sum(Payment.amount)).filter(
        Payment.status == "Success"
    ).scalar() or 0

    # Most booked movies -- JOIN + GROUP BY + COUNT
    most_booked = (
        db.session.query(Movie.title, func.count(Booking.id).label("cnt"))
        .join(Show, Show.movie_id == Movie.id)
        .join(Booking, Booking.show_id == Show.id)
        .filter(Booking.status == "Confirmed")
        .group_by(Movie.id)
        .order_by(func.count(Booking.id).desc())
        .limit(5)
        .all()
    )

    # Most popular genres -- JOIN across Movie_Genres + GROUP BY
    popular_genres = (
        db.session.query(Genre.name, func.count(Booking.id).label("cnt"))
        .join(MovieGenre, MovieGenre.genre_id == Genre.id)
        .join(Show, Show.movie_id == MovieGenre.movie_id)
        .join(Booking, Booking.show_id == Show.id)
        .filter(Booking.status == "Confirmed")
        .group_by(Genre.id)
        .order_by(func.count(Booking.id).desc())
        .limit(5)
        .all()
    )

    # Theatre-wise bookings
    theatre_bookings = (
        db.session.query(Theatre.name, func.count(Booking.id).label("cnt"))
        .join(Screen, Screen.theatre_id == Theatre.id)
        .join(Show, Show.screen_id == Screen.id)
        .join(Booking, Booking.show_id == Show.id)
        .filter(Booking.status == "Confirmed")
        .group_by(Theatre.id)
        .order_by(func.count(Booking.id).desc())
        .all()
    )

    # Daily revenue (last 14 entries) -- GROUP BY date, SUM
    daily_revenue = (
        db.session.query(func.date(Payment.created_at).label("day"), func.sum(Payment.amount))
        .filter(Payment.status == "Success")
        .group_by("day")
        .order_by("day")
        .all()
    )

    return render_template(
        "admin/dashboard.html",
        total_users=total_users, total_movies=total_movies, total_theatres=total_theatres,
        total_bookings=total_bookings, successful_payments=successful_payments,
        failed_payments=failed_payments, total_revenue=total_revenue,
        most_booked=most_booked, popular_genres=popular_genres,
        theatre_bookings=theatre_bookings, daily_revenue=daily_revenue,
    )


# ---------- Movie management ----------

@admin_bp.route("/admin/movies")
@login_required
@admin_required
def movies_manage():
    movies = Movie.query.order_by(Movie.title).all()
    return render_template("admin/movies.html", movies=movies, genres=Genre.query.all())


@admin_bp.route("/admin/movies/add", methods=["POST"])
@login_required
@admin_required
def movie_add():
    movie = Movie(
        title=request.form["title"].strip(),
        description=request.form.get("description", "").strip(),
        language=request.form["language"].strip(),
        duration_minutes=int(request.form["duration_minutes"]),
        release_date=datetime.strptime(request.form["release_date"], "%Y-%m-%d").date(),
        rating=float(request.form.get("rating") or 0),
        poster_url=request.form.get("poster_url", "").strip(),
        status=request.form.get("status", "Available"),
    )
    db.session.add(movie)
    db.session.flush()
    for gid in request.form.getlist("genres"):
        db.session.add(MovieGenre(movie_id=movie.id, genre_id=int(gid)))
    db.session.commit()
    flash(f"Movie '{movie.title}' added.", "success")
    return redirect(url_for("admin.movies_manage"))


@admin_bp.route("/admin/movies/<int:movie_id>/edit", methods=["POST"])
@login_required
@admin_required
def movie_edit(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    movie.title = request.form["title"].strip()
    movie.description = request.form.get("description", "").strip()
    movie.language = request.form["language"].strip()
    movie.duration_minutes = int(request.form["duration_minutes"])
    movie.release_date = datetime.strptime(request.form["release_date"], "%Y-%m-%d").date()
    movie.rating = float(request.form.get("rating") or 0)
    movie.poster_url = request.form.get("poster_url", "").strip()
    movie.status = request.form.get("status", "Available")

    MovieGenre.query.filter_by(movie_id=movie.id).delete()
    for gid in request.form.getlist("genres"):
        db.session.add(MovieGenre(movie_id=movie.id, genre_id=int(gid)))

    db.session.commit()
    flash(f"Movie '{movie.title}' updated.", "success")
    return redirect(url_for("admin.movies_manage"))


@admin_bp.route("/admin/movies/<int:movie_id>/delete", methods=["POST"])
@login_required
@admin_required
def movie_delete(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    if Show.query.filter_by(movie_id=movie.id).count() > 0:
        flash("Cannot delete a movie that has shows scheduled. Remove its shows first.", "danger")
        return redirect(url_for("admin.movies_manage"))
    db.session.delete(movie)
    db.session.commit()
    flash("Movie deleted.", "info")
    return redirect(url_for("admin.movies_manage"))


# ---------- Theatre / screen / seat management ----------

@admin_bp.route("/admin/theatres")
@login_required
@admin_required
def theatres_manage():
    theatres = Theatre.query.all()
    return render_template("admin/theatres.html", theatres=theatres)


@admin_bp.route("/admin/theatres/add", methods=["POST"])
@login_required
@admin_required
def theatre_add():
    t = Theatre(name=request.form["name"].strip(), location=request.form["location"].strip())
    db.session.add(t)
    db.session.commit()
    flash("Theatre added.", "success")
    return redirect(url_for("admin.theatres_manage"))


@admin_bp.route("/admin/theatres/<int:theatre_id>/screens/add", methods=["POST"])
@login_required
@admin_required
def screen_add(theatre_id):
    name = request.form["name"].strip()
    rows = int(request.form["rows"])
    seats_per_row = int(request.form["seats_per_row"])
    premium_rows = int(request.form.get("premium_rows", 0))

    screen = Screen(theatre_id=theatre_id, name=name, total_seats=rows * seats_per_row)
    db.session.add(screen)
    db.session.flush()

    for r in range(rows):
        row_letter = chr(ord("A") + r)
        seat_type = "Premium" if r < premium_rows else "Regular"
        for n in range(1, seats_per_row + 1):
            db.session.add(Seat(
                screen_id=screen.id, seat_number=f"{row_letter}{n}",
                seat_row=row_letter, seat_type=seat_type,
            ))
    db.session.commit()
    flash(f"Screen '{name}' created with {rows * seats_per_row} seats.", "success")
    return redirect(url_for("admin.theatres_manage"))


# ---------- Showtime management ----------

@admin_bp.route("/admin/shows")
@login_required
@admin_required
def shows_manage():
    shows = Show.query.order_by(Show.show_date.desc()).all()
    return render_template(
        "admin/shows.html", shows=shows,
        movies=Movie.query.all(), theatres=Theatre.query.all(),
    )


@admin_bp.route("/admin/shows/add", methods=["POST"])
@login_required
@admin_required
def show_add():
    movie_id = int(request.form["movie_id"])
    screen_id = int(request.form["screen_id"])
    show_date = datetime.strptime(request.form["show_date"], "%Y-%m-%d").date()
    show_time = datetime.strptime(request.form["show_time"], "%H:%M").time()
    base_price = float(request.form["base_price"])
    premium_price = float(request.form.get("premium_price") or base_price * 1.5)

    show = Show(movie_id=movie_id, screen_id=screen_id, show_date=show_date,
                show_time=show_time, base_price=base_price)
    db.session.add(show)
    db.session.flush()

    for seat in Seat.query.filter_by(screen_id=screen_id).all():
        price = premium_price if seat.seat_type == "Premium" else base_price
        db.session.add(ShowSeat(show_id=show.id, seat_id=seat.id, status="Available", price=price))

    db.session.commit()
    flash("Showtime created.", "success")
    return redirect(url_for("admin.shows_manage"))


@admin_bp.route("/admin/screens/<int:screen_id>/seats.json")
@login_required
@admin_required
def screen_seat_count(screen_id):
    screen = Screen.query.get_or_404(screen_id)
    return jsonify({"total_seats": screen.total_seats})


# ---------- Users / bookings / payments / reports ----------

@admin_bp.route("/admin/users")
@login_required
@admin_required
def users_list():
    users = User.query.filter_by(is_admin=False).order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=users)


@admin_bp.route("/admin/bookings")
@login_required
@admin_required
def bookings_list():
    bookings = Booking.query.order_by(Booking.created_at.desc()).all()
    return render_template("admin/bookings.html", bookings=bookings)


@admin_bp.route("/admin/reports")
@login_required
@admin_required
def reports():
    # NOTE: strftime() is SQLite's date-formatting function (this app's dev
    # default engine). On MySQL 8.0 the equivalent is:
    #   SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, SUM(amount)
    #   FROM payments WHERE status = 'Success' GROUP BY month ORDER BY month;
    # -- see database/reports.sql for the MySQL version of every report query.
    monthly_revenue = (
        db.session.query(
            func.strftime("%Y-%m", Payment.created_at).label("month"),
            func.sum(Payment.amount),
        )
        .filter(Payment.status == "Success")
        .group_by("month")
        .order_by("month")
        .all()
    )
    return render_template("admin/reports.html", monthly_revenue=monthly_revenue)
