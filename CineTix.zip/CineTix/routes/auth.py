from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user

from models import db, User, Genre, UserPreference

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("movies.home"))

    genres = Genre.query.order_by(Genre.name).all()

    if request.method == "POST":
        username = request.form["username"].strip()
        email = request.form["email"].strip().lower()
        full_name = request.form["full_name"].strip()
        phone = request.form.get("phone", "").strip()
        password = request.form["password"]
        confirm = request.form["confirm_password"]
        chosen_genre_ids = request.form.getlist("genres")

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html", genres=genres)

        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already registered.", "danger")
            return render_template("register.html", genres=genres)

        user = User(username=username, email=email, full_name=full_name, phone=phone)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()

        for gid in chosen_genre_ids:
            db.session.add(UserPreference(user_id=user.id, genre_id=int(gid)))

        db.session.commit()
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html", genres=genres)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("movies.home"))

    if request.method == "POST":
        identifier = request.form["username"].strip()
        password = request.form["password"]
        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier.lower())
        ).first()

        if user and user.check_password(password):
            login_user(user)
            flash(f"Welcome back, {user.full_name}!", "success")
            next_page = request.args.get("next")
            if user.is_admin:
                return redirect(url_for("admin.dashboard"))
            return redirect(next_page or url_for("movies.home"))

        flash("Invalid username/email or password.", "danger")

    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("movies.home"))


@auth_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    genres = Genre.query.order_by(Genre.name).all()
    current_pref_ids = {p.genre_id for p in current_user.preferences}

    if request.method == "POST":
        current_user.full_name = request.form["full_name"].strip()
        current_user.phone = request.form.get("phone", "").strip()

        UserPreference.query.filter_by(user_id=current_user.id).delete()
        for gid in request.form.getlist("genres"):
            db.session.add(UserPreference(user_id=current_user.id, genre_id=int(gid)))

        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("auth.profile"))

    return render_template("profile.html", genres=genres, current_pref_ids=current_pref_ids)
