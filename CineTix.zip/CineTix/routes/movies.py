from datetime import date
from flask import Blueprint, render_template, request
from flask_login import current_user

from models import Movie, Genre, Theatre, Show
from services.recommendation import get_recommendations

movies_bp = Blueprint("movies", __name__)


@movies_bp.route("/")
def home():
    now_showing = Movie.query.filter_by(status="Available").order_by(Movie.rating.desc()).limit(8).all()
    upcoming = Movie.query.filter(Movie.status == "Upcoming").limit(6).all()

    recommended = []
    if current_user.is_authenticated:
        recommended = get_recommendations(current_user.id, limit=6)

    return render_template(
        "home.html", now_showing=now_showing, upcoming=upcoming, recommended=recommended
    )


@movies_bp.route("/movies")
def listing():
    query = Movie.query

    search = request.args.get("q", "").strip()
    genre_id = request.args.get("genre", type=int)
    language = request.args.get("language", "").strip()
    sort = request.args.get("sort", "rating")
    availability = request.args.get("availability", "")

    if search:
        query = query.filter(Movie.title.ilike(f"%{search}%"))
    if language:
        query = query.filter(Movie.language == language)
    if availability:
        query = query.filter(Movie.status == availability)
    if genre_id:
        query = query.join(Movie.genres).filter_by(genre_id=genre_id)

    if sort == "rating":
        query = query.order_by(Movie.rating.desc())
    elif sort == "release":
        query = query.order_by(Movie.release_date.desc())
    elif sort == "title":
        query = query.order_by(Movie.title.asc())

    movies = query.all()
    genres = Genre.query.order_by(Genre.name).all()
    languages = [row[0] for row in Movie.query.with_entities(Movie.language).distinct()]

    return render_template(
        "movies_list.html", movies=movies, genres=genres, languages=languages,
        selected_genre=genre_id, selected_language=language, selected_sort=sort,
        selected_availability=availability, search=search,
    )


@movies_bp.route("/movies/<int:movie_id>")
def detail(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    shows = (
        Show.query.filter_by(movie_id=movie_id)
        .filter(Show.show_date >= date.today())
        .order_by(Show.show_date, Show.show_time)
        .all()
    )
    shows_by_theatre = {}
    for s in shows:
        shows_by_theatre.setdefault(s.theatre, []).append(s)

    return render_template("movie_detail.html", movie=movie, shows_by_theatre=shows_by_theatre)
