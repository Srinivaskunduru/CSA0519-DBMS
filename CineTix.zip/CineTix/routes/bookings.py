from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file, abort
from flask_login import login_required, current_user

from models import Show, ShowSeat, Booking
from services.booking_service import cancel_booking, BookingError
from services.ticket_service import build_ticket_pdf
from config import Config

bookings_bp = Blueprint("bookings", __name__)


@bookings_bp.route("/shows/<int:show_id>/seats", methods=["GET", "POST"])
@login_required
def select_seats(show_id):
    show = Show.query.get_or_404(show_id)
    screen = show.screen

    # Build row x seat_number grid, grouped by row, ordered by seat_number
    show_seats = (
        ShowSeat.query.filter_by(show_id=show_id)
        .join(ShowSeat.seat)
        .order_by("seat_row", "seat_number")
        .all()
    )
    rows = {}
    for ss in show_seats:
        rows.setdefault(ss.seat.seat_row, []).append(ss)

    if request.method == "POST":
        selected_ids = request.form.getlist("seat_ids")
        if not selected_ids:
            flash("Please select at least one seat.", "warning")
            return redirect(url_for("bookings.select_seats", show_id=show_id))
        ids_param = ",".join(selected_ids)
        return redirect(url_for("payments.checkout", show_id=show_id, seats=ids_param))

    return render_template(
        "seat_selection.html", show=show, screen=screen, rows=sorted(rows.items())
    )


@bookings_bp.route("/my-bookings")
@login_required
def my_bookings():
    bookings = (
        Booking.query.filter_by(user_id=current_user.id)
        .order_by(Booking.created_at.desc())
        .all()
    )
    return render_template("my_bookings.html", bookings=bookings)


@bookings_bp.route("/bookings/<int:booking_id>/cancel", methods=["POST"])
@login_required
def cancel(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        abort(403)
    try:
        cancel_booking(booking, cutoff_hours=Config.CANCELLATION_CUTOFF_HOURS)
        flash("Booking cancelled and seats released.", "success")
    except BookingError as e:
        flash(str(e), "danger")
    return redirect(url_for("bookings.my_bookings"))


@bookings_bp.route("/bookings/<int:booking_id>/ticket")
@login_required
def view_ticket(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        abort(403)
    if booking.status != "Confirmed" or not booking.ticket:
        flash("Ticket is only available for confirmed bookings.", "warning")
        return redirect(url_for("bookings.my_bookings"))
    return render_template("ticket.html", booking=booking)


@bookings_bp.route("/bookings/<int:booking_id>/ticket.pdf")
@login_required
def download_ticket(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        abort(403)
    if booking.status != "Confirmed" or not booking.ticket:
        abort(404)
    pdf_path = build_ticket_pdf(booking)
    return send_file(pdf_path, as_attachment=True, download_name=f"{booking.booking_code}.pdf")
