from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user

from models import Show, ShowSeat
from services.booking_service import create_booking_and_charge, BookingError

payments_bp = Blueprint("payments", __name__)


@payments_bp.route("/checkout")
@login_required
def checkout():
    show_id = request.args.get("show_id", type=int)
    seats_param = request.args.get("seats", "")
    show = Show.query.get_or_404(show_id)

    try:
        seat_ids = [int(s) for s in seats_param.split(",") if s]
    except ValueError:
        abort(400)

    show_seats = ShowSeat.query.filter(ShowSeat.id.in_(seat_ids)).all()
    if not show_seats or any(ss.status != "Available" for ss in show_seats):
        flash("One or more selected seats are no longer available. Please reselect.", "danger")
        return redirect(url_for("bookings.select_seats", show_id=show_id))

    total = sum(float(ss.price) for ss in show_seats)

    return render_template(
        "payment.html", show=show, show_seats=show_seats, total=total, seats_param=seats_param
    )


@payments_bp.route("/checkout/pay", methods=["POST"])
@login_required
def pay():
    show_id = request.form.get("show_id", type=int)
    seats_param = request.form.get("seats_param", "")
    method = request.form.get("method", "Card")
    simulate_failure = request.form.get("simulate_failure") == "1"

    seat_ids = [int(s) for s in seats_param.split(",") if s]

    try:
        booking, payment = create_booking_and_charge(
            user_id=current_user.id,
            show_id=show_id,
            show_seat_ids=seat_ids,
            payment_method=method,
            card_outcome="force_fail" if simulate_failure else "auto",
        )
        flash(f"Payment successful! Booking {booking.booking_code} confirmed.", "success")
        return redirect(url_for("bookings.view_ticket", booking_id=booking.id))
    except BookingError as e:
        flash(str(e), "danger")
        return redirect(url_for("bookings.select_seats", show_id=show_id))
