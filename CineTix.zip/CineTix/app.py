import os
from datetime import datetime

from flask import Flask, render_template
from flask_login import LoginManager

from config import Config
from models import db, User

from routes.auth import auth_bp
from routes.movies import movies_bp
from routes.bookings import bookings_bp
from routes.payments import payments_bp
from routes.admin import admin_bp


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    app.register_blueprint(auth_bp)
    app.register_blueprint(movies_bp)
    app.register_blueprint(bookings_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(admin_bp)

    @app.context_processor
    def inject_globals():
        return {"current_year": datetime.utcnow().year}

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.cli.command("seed-db")
    def seed_db():
        """flask --app app.py seed-db  -- creates tables and loads demo data."""
        from seed import run_seed
        run_seed(app)

    return app


app = create_app()

if __name__ == "__main__":
    os.makedirs(os.path.join(os.path.dirname(__file__), "static", "qrcodes"), exist_ok=True)
    os.makedirs(os.path.join(os.path.dirname(__file__), "generated_tickets"), exist_ok=True)

    with app.app_context():
        db.create_all()

    app.run(debug=True, host="0.0.0.0", port=5001)
