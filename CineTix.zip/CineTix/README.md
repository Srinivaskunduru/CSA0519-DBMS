# CineTix — An AI-Enabled Smart Movie Ticket Reservation System

A DBMS capstone project: a working Flask + MySQL (SQLite-by-default for
instant local demo) movie ticket booking platform, built so the database
layer — not the frontend — is the thing actually being demonstrated.

## 1. What's implemented

- **User management**: registration, login/logout, password hashing
  (Werkzeug), session auth (Flask-Login), profile editing.
- **Movie & theatre browsing**: search, genre/language filters, sort by
  rating/release date, movie detail page with live showtimes.
- **AI-style content-based recommendations**: scored from the user's
  declared genre preferences, past high ratings, and watch history —
  computed live from the database every time (`services/recommendation.py`),
  never a hardcoded list.
- **Interactive seat selection**: live seat map (green = available,
  red = booked, blue = selected), computed per-show from `show_seats`.
- **Transaction-safe booking + simulated payment**: `services/booking_service.py`
  implements lock → book → charge → commit, or release-and-rollback on
  payment failure (see `database/transactions.sql` for the raw-SQL version).
- **Digital tickets**: QR code + downloadable PDF ticket per confirmed
  booking (`services/ticket_service.py`).
- **Booking history & cancellation**, governed by a cancellation cutoff.
- **Admin dashboard**: manage movies/theatres/screens/showtimes, view
  users/bookings/payments, and live Chart.js reports (most booked movies,
  popular genres, theatre-wise bookings, daily revenue) built from real
  `JOIN`/`GROUP BY`/`COUNT`/`SUM`/`AVG` queries.

## 2. Project structure

```
CineTix/
  app.py                  Flask app factory + entrypoint
  config.py                MySQL/SQLite configuration
  seed.py                   Python demo-data seeder
  requirements.txt
  database/
    schema.sql              All 16 tables: PK/FK/constraints (MySQL 8.0 DDL)
    sample_data.sql          DML sample rows
    views.sql                 CREATE VIEW examples
    indexes.sql               CREATE INDEX examples
    reports.sql                JOIN/GROUP BY/HAVING/subquery reports
    transactions.sql           START TRANSACTION / COMMIT / ROLLBACK demo
  models/                    SQLAlchemy models (user, movie, theatre, booking, payment)
  routes/                    Flask blueprints (auth, movies, bookings, payments, admin)
  services/                  recommendation.py, booking_service.py, ticket_service.py
  templates/                 Jinja2 templates (cinema dark-navy/gold/red theme)
  static/                    css/js/images, generated QR codes
  generated_tickets/          PDF tickets land here
  tests/                     Smoke tests
```

## 3. Database design (the core deliverable)

16 tables: `Users, Movies, Genres, Movie_Genres, Theatres, Screens, Seats,
Shows, Show_Seats, Bookings, Booking_Seats, Payments, Tickets,
User_Preferences, Movie_Ratings, Watch_History`.

| Concept | Where to see it |
|---|---|
| Primary / Foreign Keys | `database/schema.sql` |
| 1:1 (Booking↔Payment, Booking↔Ticket) | `schema.sql` (`UNIQUE` FK column) |
| 1:N (User→Bookings, Movie→Shows, Theatre→Screens...) | `schema.sql` comments + `models/*.py` |
| M:N (Movies↔Genres, Users↔Genres, Users↔Movies ratings/history) | `movie_genres`, `user_preferences`, `movie_ratings`, `watch_history` |
| Normalization (1NF–3NF) | Note at the bottom of `schema.sql` |
| DDL | `database/schema.sql` |
| DML | `database/sample_data.sql` |
| SELECT / JOIN (INNER, LEFT) / GROUP BY / HAVING / COUNT, SUM, AVG / Subqueries | `database/reports.sql` |
| Views | `database/views.sql` |
| Indexes | `database/indexes.sql` |
| Transactions / COMMIT / ROLLBACK / ACID | `database/transactions.sql` and `services/booking_service.py` |
| Constraints (NOT NULL, UNIQUE, CHECK) | throughout `schema.sql` |

## 4. Running it locally (quick demo, SQLite — zero setup)

```bash
cd CineTix
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt
python seed.py                  # creates cinetix.db and loads demo data
python app.py                   # http://127.0.0.1:5000
```

Demo logins:
- Admin: `admin` / `admin123`
- User: `demo` / `demo123`

## 5. Running it against real MySQL 8.0 (the submission configuration)

```bash
mysql -u root -p -e "CREATE DATABASE cinetix CHARACTER SET utf8mb4;"
mysql -u root -p cinetix < database/schema.sql
mysql -u root -p cinetix < database/sample_data.sql
mysql -u root -p cinetix < database/views.sql
mysql -u root -p cinetix < database/indexes.sql

export MYSQL_HOST=localhost
export MYSQL_USER=root
export MYSQL_PASSWORD=yourpassword
export MYSQL_DB=cinetix

pip install -r requirements.txt
python app.py
```

`config.py` automatically switches `SQLALCHEMY_DATABASE_URI` to MySQL
whenever `MYSQL_HOST` is set — nothing else in the codebase changes.

## 6. Booking policy

- Seats can only be selected while `Available`; they move to `Locked`
  during checkout and `Booked` only after a successful simulated payment.
- A failed payment rolls the whole transaction back and releases the seats.
- Cancellation is only allowed while `Confirmed` and more than
  `CANCELLATION_CUTOFF_HOURS` (default 2) before showtime; cancelling marks
  the payment `Refunded` and frees the seats again.

## 7. Notes on scope

This is a complete, runnable module of the full capstone brief: every
table, relationship, transaction path, and page listed in the brief
exists and works end-to-end. Things intentionally kept simple for an
academic demo rather than production use:
- Payment gateway is fully simulated — no real card data is ever
  collected, matching the brief's explicit instruction.
- Poster images default to placeholder URLs (`picsum.photos`) in
  `seed.py`; swap in real poster URLs/files for a polished demo.
- `DATE_FORMAT`/`strftime` differ between MySQL and SQLite — the few
  dashboard queries that use date-bucketing have both forms noted inline
  in `routes/admin.py` and `database/reports.sql`.
