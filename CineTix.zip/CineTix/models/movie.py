from datetime import date
from . import db


class Genre(db.Model):
    __tablename__ = "genres"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)


class Movie(db.Model):
    __tablename__ = "movies"
    __table_args__ = (
        db.CheckConstraint("rating >= 0 AND rating <= 10", name="ck_movie_rating_range"),
        db.CheckConstraint("duration_minutes > 0", name="ck_duration_positive"),
    )

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    language = db.Column(db.String(30), nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)
    release_date = db.Column(db.Date, nullable=False)
    rating = db.Column(db.Numeric(3, 1), default=0)
    poster_url = db.Column(db.String(255))
    status = db.Column(db.String(20), nullable=False, default="Available")  # Available / Upcoming

    genres = db.relationship("MovieGenre", backref="movie", lazy="joined",
                              cascade="all, delete-orphan")
    shows = db.relationship("Show", backref="movie", lazy="dynamic")

    @property
    def genre_names(self):
        return [mg.genre.name for mg in self.genres]

    @property
    def is_upcoming(self):
        return self.release_date > date.today() or self.status == "Upcoming"


class MovieGenre(db.Model):
    """Resolves the Movies <-> Genres many-to-many relationship."""
    __tablename__ = "movie_genres"
    __table_args__ = (db.UniqueConstraint("movie_id", "genre_id", name="uq_movie_genre"),)

    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.Integer, db.ForeignKey("movies.id"), nullable=False)
    genre_id = db.Column(db.Integer, db.ForeignKey("genres.id"), nullable=False)

    genre = db.relationship("Genre")
