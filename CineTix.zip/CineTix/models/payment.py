from datetime import datetime
from . import db


class Payment(db.Model):
    __tablename__ = "payments"
    __table_args__ = (db.CheckConstraint(
        "status IN ('Pending','Success','Failed','Refunded')", name="ck_payment_status"),)

    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("bookings.id"), unique=True, nullable=False)
    transaction_id = db.Column(db.String(40), unique=True, nullable=False)
    amount = db.Column(db.Numeric(8, 2), nullable=False)
    method = db.Column(db.String(30), nullable=False)  # Card / UPI / NetBanking / Wallet
    status = db.Column(db.String(20), nullable=False, default="Pending")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Ticket(db.Model):
    __tablename__ = "tickets"

    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("bookings.id"), unique=True, nullable=False)
    ticket_code = db.Column(db.String(40), unique=True, nullable=False)
    qr_path = db.Column(db.String(255))
    issued_at = db.Column(db.DateTime, default=datetime.utcnow)
