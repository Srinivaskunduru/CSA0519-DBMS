from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import model modules so SQLAlchemy registers every mapped class
# against this single `db` instance before db.create_all() runs.
from .user import User, UserPreference, MovieRating, WatchHistory          # noqa: E402,F401
from .movie import Movie, Genre, MovieGenre                                 # noqa: E402,F401
from .theatre import Theatre, Screen, Seat, Show, ShowSeat                  # noqa: E402,F401
from .booking import Booking, BookingSeat                                   # noqa: E402,F401
from .payment import Payment, Ticket                                       # noqa: E402,F401
