from . import db


class Theatre(db.Model):
    __tablename__ = "theatres"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    location = db.Column(db.String(255), nullable=False)

    screens = db.relationship("Screen", backref="theatre", lazy="dynamic",
                               cascade="all, delete-orphan")


class Screen(db.Model):
    __tablename__ = "screens"

    id = db.Column(db.Integer, primary_key=True)
    theatre_id = db.Column(db.Integer, db.ForeignKey("theatres.id"), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    total_seats = db.Column(db.Integer, nullable=False)

    seats = db.relationship("Seat", backref="screen", lazy="dynamic",
                             cascade="all, delete-orphan")
    shows = db.relationship("Show", backref="screen", lazy="dynamic")


class Seat(db.Model):
    __tablename__ = "seats"
    __table_args__ = (db.UniqueConstraint("screen_id", "seat_number", name="uq_screen_seat"),)

    id = db.Column(db.Integer, primary_key=True)
    screen_id = db.Column(db.Integer, db.ForeignKey("screens.id"), nullable=False)
    seat_number = db.Column(db.String(10), nullable=False)   # e.g. A1, A2
    seat_row = db.Column(db.String(5), nullable=False)       # e.g. A
    seat_type = db.Column(db.String(20), nullable=False, default="Regular")  # Regular / Premium


class Show(db.Model):
    __tablename__ = "shows"
    __table_args__ = (db.CheckConstraint("base_price > 0", name="ck_base_price_positive"),)

    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.Integer, db.ForeignKey("movies.id"), nullable=False)
    screen_id = db.Column(db.Integer, db.ForeignKey("screens.id"), nullable=False)
    show_date = db.Column(db.Date, nullable=False)
    show_time = db.Column(db.Time, nullable=False)
    base_price = db.Column(db.Numeric(8, 2), nullable=False)

    show_seats = db.relationship("ShowSeat", backref="show", lazy="dynamic",
                                  cascade="all, delete-orphan")
    bookings = db.relationship("Booking", backref="show", lazy="dynamic")

    @property
    def theatre(self):
        return self.screen.theatre


class ShowSeat(db.Model):
    """One row per seat per show -- this is what actually gets locked/booked,
    never the physical Seat row, so the same seat is free again in a different show."""
    __tablename__ = "show_seats"
    __table_args__ = (db.UniqueConstraint("show_id", "seat_id", name="uq_show_seat"),)

    id = db.Column(db.Integer, primary_key=True)
    show_id = db.Column(db.Integer, db.ForeignKey("shows.id"), nullable=False)
    seat_id = db.Column(db.Integer, db.ForeignKey("seats.id"), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Available")  # Available/Locked/Booked
    price = db.Column(db.Numeric(8, 2), nullable=False)

    seat = db.relationship("Seat")
