from datetime import datetime
from . import db


class Booking(db.Model):
    __tablename__ = "bookings"

    id = db.Column(db.Integer, primary_key=True)
    booking_code = db.Column(db.String(20), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    show_id = db.Column(db.Integer, db.ForeignKey("shows.id"), nullable=False)
    total_amount = db.Column(db.Numeric(8, 2), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Pending")
    # Pending -> Confirmed -> (Cancelled | Completed)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    seats = db.relationship("BookingSeat", backref="booking", lazy="joined",
                             cascade="all, delete-orphan")
    payment = db.relationship("Payment", backref="booking", uselist=False,
                               cascade="all, delete-orphan")
    ticket = db.relationship("Ticket", backref="booking", uselist=False,
                              cascade="all, delete-orphan")


class BookingSeat(db.Model):
    __tablename__ = "booking_seats"
    __table_args__ = (db.UniqueConstraint("booking_id", "show_seat_id", name="uq_booking_showseat"),)

    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("bookings.id"), nullable=False)
    show_seat_id = db.Column(db.Integer, db.ForeignKey("show_seats.id"), nullable=False)

    show_seat = db.relationship("ShowSeat")
