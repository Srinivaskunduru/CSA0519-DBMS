import os
import random
import string

import qrcode
from reportlab.lib.pagesizes import A6
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

from models import db, Ticket
from config import Config


def _generate_code(prefix, length=10):
    chars = string.ascii_uppercase + string.digits
    return prefix + "".join(random.choices(chars, k=length))


def issue_ticket(booking):
    os.makedirs(Config.QR_CODE_FOLDER, exist_ok=True)
    ticket_code = _generate_code("TKT")

    qr_payload = (
        f"CineTix Ticket\nBooking:{booking.booking_code}\nTicket:{ticket_code}\n"
        f"Movie:{booking.show.movie.title}\nShow:{booking.show.show_date} {booking.show.show_time}"
    )
    qr_img = qrcode.make(qr_payload)
    qr_filename = f"{ticket_code}.png"
    qr_path_abs = os.path.join(Config.QR_CODE_FOLDER, qr_filename)
    qr_img.save(qr_path_abs)

    ticket = Ticket(
        booking_id=booking.id,
        ticket_code=ticket_code,
        qr_path=f"qrcodes/{qr_filename}",
    )
    db.session.add(ticket)
    db.session.flush()
    return ticket


def build_ticket_pdf(booking):
    """Renders a boarding-pass style PDF ticket and returns the absolute file path."""
    os.makedirs(Config.TICKET_FOLDER, exist_ok=True)
    ticket = booking.ticket
    show = booking.show
    movie = show.movie
    theatre = show.theatre

    pdf_path = os.path.join(Config.TICKET_FOLDER, f"{booking.booking_code}.pdf")
    c = canvas.Canvas(pdf_path, pagesize=A6)
    width, height = A6

    c.setFillColorRGB(0.043, 0.071, 0.125)  # navy
    c.rect(0, 0, width, height, fill=1, stroke=0)

    c.setFillColorRGB(0.83, 0.69, 0.22)  # gold
    c.setFont("Helvetica-Bold", 14)
    c.drawString(10 * mm, height - 14 * mm, "CineTix")

    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 11)
    c.drawString(10 * mm, height - 24 * mm, movie.title[:30])

    c.setFont("Helvetica", 8)
    lines = [
        f"Theatre: {theatre.name}",
        f"Date: {show.show_date}   Time: {show.show_time}",
        f"Seats: {', '.join(bs.show_seat.seat.seat_number for bs in booking.seats)}",
        f"Booking ID: {booking.booking_code}",
        f"Amount Paid: Rs. {booking.total_amount}",
        f"Payment Status: {booking.payment.status if booking.payment else 'N/A'}",
    ]
    y = height - 32 * mm
    for line in lines:
        c.drawString(10 * mm, y, line)
        y -= 5 * mm

    qr_abs_path = os.path.join(Config.QR_CODE_FOLDER, os.path.basename(ticket.qr_path))
    if os.path.exists(qr_abs_path):
        c.drawImage(qr_abs_path, width - 32 * mm, 6 * mm, width=26 * mm, height=26 * mm)

    c.showPage()
    c.save()
    return pdf_path
