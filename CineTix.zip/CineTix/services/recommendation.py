"""
Content-based recommendation engine.

Score for a candidate movie = weighted sum of:
  - genre overlap with the user's declared UserPreference genres
  - genre overlap with genres of movies the user rated highly (>=4) or watched
  - the movie's own average community rating (MovieRating), as a tie-breaker

Everything here is computed from live rows in Movies / Genres / Movie_Genres /
User_Preferences / Movie_Ratings / Watch_History -- there is no hardcoded
sample list, per the brief.
"""
from collections import Counter
from sqlalchemy import func
from models import db, Movie, MovieGenre, UserPreference, MovieRating, WatchHistory, Booking, Show


def _genre_ids_for_movie(movie_id):
    rows = MovieGenre.query.filter_by(movie_id=movie_id).all()
    return {r.genre_id for r in rows}


def _already_seen_movie_ids(user_id):
    """Movies the user already booked or watched -- don't recommend these again."""
    booked = {
        b.show.movie_id
        for b in Booking.query.filter_by(user_id=user_id).filter(Booking.status != "Cancelled")
    }
    watched = {w.movie_id for w in WatchHistory.query.filter_by(user_id=user_id)}
    return booked | watched


def get_recommendations(user_id, limit=6):
    # 1. Build the user's genre-affinity weights
    affinity = Counter()

    for pref in UserPreference.query.filter_by(user_id=user_id):
        affinity[pref.genre_id] += 3  # explicit preference = strongest signal

    for rating in MovieRating.query.filter_by(user_id=user_id).filter(MovieRating.rating >= 4):
        for gid in _genre_ids_for_movie(rating.movie_id):
            affinity[gid] += 2  # liked a movie in this genre

    for watch in WatchHistory.query.filter_by(user_id=user_id):
        for gid in _genre_ids_for_movie(watch.movie_id):
            affinity[gid] += 1  # watched something in this genre

    seen = _already_seen_movie_ids(user_id)

    # 2. Average community rating per movie (AVG aggregate, real SQL)
    avg_ratings = dict(
        db.session.query(MovieRating.movie_id, func.avg(MovieRating.rating))
        .group_by(MovieRating.movie_id)
        .all()
    )

    candidates = Movie.query.filter(Movie.status == "Available").all()

    scored = []
    for movie in candidates:
        if movie.id in seen:
            continue
        movie_genre_ids = _genre_ids_for_movie(movie.id)
        genre_score = sum(affinity.get(gid, 0) for gid in movie_genre_ids)
        community_score = float(avg_ratings.get(movie.id, movie.rating or 0))
        # Genre affinity dominates; community rating only breaks ties.
        total_score = genre_score * 10 + community_score
        if genre_score > 0:
            scored.append((total_score, movie))

    scored.sort(key=lambda pair: pair[0], reverse=True)
    recommended = [m for _, m in scored[:limit]]

    # 3. Cold-start fallback: no preference/history yet -> show top-rated available movies
    if not recommended:
        recommended = (
            Movie.query.filter(Movie.status == "Available", ~Movie.id.in_(seen or [0]))
            .order_by(Movie.rating.desc())
            .limit(limit)
            .all()
        )
    return recommended
