"""
Booking service -- this is where the DBMS "transactions / ACID" requirement
from the brief is actually implemented.

Flow for services.booking_service.create_booking_and_charge():
  1. BEGIN (SQLAlchemy opens a transaction implicitly on first write)
  2. Re-check each requested ShowSeat is still 'Available', with a row lock
     (SELECT ... FOR UPDATE on MySQL -- see _lock_show_seats) so two users
     cannot both grab the same seat for the same show at the same time.
  3. Flip those ShowSeats to 'Locked' and create the Booking + BookingSeat
     rows (status 'Pending').
  4. Call the simulated payment gateway.
  5a. Success -> ShowSeats -> 'Booked', Booking -> 'Confirmed', Payment row
      'Success', ticket generated.  COMMIT.
  5b. Failure -> ROLLBACK the whole transaction: seats go straight back to
      'Available' and no half-finished booking is left in the database.

A UNIQUE constraint on (show_id, seat_id) in show_seats, plus the explicit
status check below, is the belt-and-braces guarantee against double-booking
even under a race condition.
"""
import random
import string
from datetime import datetime, timedelta

from sqlalchemy.exc import SQLAlchemyError

from models import db, ShowSeat, Booking, BookingSeat, Payment, Show
from services.ticket_service import issue_ticket


class BookingError(Exception):
    pass


def _generate_code(prefix, length=8):
    chars = string.ascii_uppercase + string.digits
    return prefix + "".join(random.choices(chars, k=length))


def _lock_show_seats(show_seat_ids):
    """SELECT ... FOR UPDATE on MySQL/Postgres so concurrent bookings on the
    same seats serialize instead of racing. SQLite has no row locks, so the
    unique constraint + status re-check below is what actually protects it
    there; the .with_for_update() call is a no-op on SQLite and harmless."""
    query = ShowSeat.query.filter(ShowSeat.id.in_(show_seat_ids))
    try:
        query = query.with_for_update()
    except Exception:
        pass
    return {s.id: s for s in query.all()}


def create_booking_and_charge(user_id, show_id, show_seat_ids, payment_method, card_outcome="auto"):
    """
    card_outcome: 'auto' (succeeds unless seats conflict), 'force_fail'
    (used by the demo Payment page's "simulate failed payment" button so the
    rollback path can be demonstrated live).
    Returns (booking, payment) on success. Raises BookingError on failure.
    """
    if not show_seat_ids:
        raise BookingError("No seats selected.")

    try:
        locked_seats = _lock_show_seats(show_seat_ids)

        # Validate every requested seat is still free
        unavailable = [sid for sid in show_seat_ids
                       if sid not in locked_seats or locked_seats[sid].status != "Available"]
        if unavailable:
            db.session.rollback()
            raise BookingError(
                "Sorry, one or more selected seats were just booked by someone else. "
                "Please reselect your seats."
            )

        show = Show.query.get(show_id)
        if show is None:
            db.session.rollback()
            raise BookingError("Show not found.")

        total_amount = sum(float(locked_seats[sid].price) for sid in show_seat_ids)

        # Step: lock seats + create Pending booking
        for sid in show_seat_ids:
            locked_seats[sid].status = "Locked"

        booking = Booking(
            booking_code=_generate_code("BKG"),
            user_id=user_id,
            show_id=show_id,
            total_amount=total_amount,
            status="Pending",
        )
        db.session.add(booking)
        db.session.flush()  # get booking.id without committing

        for sid in show_seat_ids:
            db.session.add(BookingSeat(booking_id=booking.id, show_seat_id=sid))

        db.session.flush()

        # Step: simulated payment gateway
        payment_success = card_outcome != "force_fail"

        payment = Payment(
            booking_id=booking.id,
            transaction_id=_generate_code("TXN", 12),
            amount=total_amount,
            method=payment_method,
            status="Success" if payment_success else "Failed",
        )
        db.session.add(payment)

        if payment_success:
            for sid in show_seat_ids:
                locked_seats[sid].status = "Booked"
            booking.status = "Confirmed"
            db.session.flush()
            issue_ticket(booking)   # creates Ticket row + QR image
            db.session.commit()
            return booking, payment
        else:
            # Payment failed -> release seats, do not leave them Locked/Booked
            for sid in show_seat_ids:
                locked_seats[sid].status = "Available"
            booking.status = "Cancelled"
            db.session.commit()  # keep the Failed payment + Cancelled booking as an audit trail
            raise BookingError("Payment failed. Your seats have been released -- please try again.")

    except BookingError:
        raise
    except SQLAlchemyError:
        db.session.rollback()
        raise BookingError("A database error occurred. The transaction was rolled back.")


def cancel_booking(booking, cutoff_hours=2):
    show = booking.show
    show_datetime = datetime.combine(show.show_date, show.show_time)
    if show_datetime - datetime.utcnow() < timedelta(hours=cutoff_hours):
        raise BookingError(
            f"Bookings can only be cancelled at least {cutoff_hours} hours before showtime."
        )
    if booking.status != "Confirmed":
        raise BookingError("Only confirmed bookings can be cancelled.")

    try:
        for bseat in booking.seats:
            bseat.show_seat.status = "Available"
        booking.status = "Cancelled"
        if booking.payment:
            booking.payment.status = "Refunded"
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        raise BookingError("Cancellation failed due to a database error. Nothing was changed.")
