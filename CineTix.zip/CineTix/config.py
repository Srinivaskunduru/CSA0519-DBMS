"""
CineTix configuration.

This project is written for MySQL 8.0 (as required by the DBMS capstone
brief). To make it runnable immediately with zero external setup, it
defaults to a local SQLite file when MYSQL_HOST is not set. Nothing about
the schema, models or queries changes between the two — SQLAlchemy and
the raw SQL in database/*.sql both target standard relational features
(PK/FK, constraints, joins, transactions) that work on both engines.

To switch to real MySQL 8.0 (recommended for the actual submission):
  1. Create the database:  mysql -u root -p -e "CREATE DATABASE cinetix"
  2. Run database/schema.sql, then database/sample_data.sql,
     database/views.sql and database/indexes.sql against it.
  3. Set these environment variables before running app.py:
       MYSQL_HOST=localhost
       MYSQL_USER=root
       MYSQL_PASSWORD=yourpassword
       MYSQL_DB=cinetix
"""

import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "cinetix-dev-secret-change-me")

    MYSQL_HOST = os.environ.get("MYSQL_HOST")
    MYSQL_USER = os.environ.get("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
    MYSQL_DB = os.environ.get("MYSQL_DB", "cinetix")
    MYSQL_PORT = os.environ.get("MYSQL_PORT", "3306")

    if MYSQL_HOST:
        SQLALCHEMY_DATABASE_URI = (
            f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}"
            f"@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}"
        )
    else:
        SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "cinetix.db")

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    QR_CODE_FOLDER = os.path.join(BASE_DIR, "static", "qrcodes")
    TICKET_FOLDER = os.path.join(BASE_DIR, "generated_tickets")
    POSTER_FOLDER = os.path.join(BASE_DIR, "static", "images", "posters")

    # Booking policy
    CANCELLATION_CUTOFF_HOURS = 2   # cannot cancel within 2 hrs of showtime
    SEAT_LOCK_MINUTES = 5           # how long a seat stays "Locked" before auto release
