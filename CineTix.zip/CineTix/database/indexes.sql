-- =====================================================================
-- CineTix — Indexes
-- Demonstrates: INDEXES for query performance on frequently filtered /
-- joined columns. Primary keys and UNIQUE constraints already create
-- indexes automatically (see schema.sql); these are the additional,
-- deliberate ones for query patterns the app actually uses.
-- =====================================================================
USE cinetix;

-- Movie search/filter/sort: WHERE title LIKE ..., WHERE language = ...,
-- ORDER BY rating DESC, WHERE status = ...
CREATE INDEX idx_movies_language ON movies(language);
CREATE INDEX idx_movies_status   ON movies(status);
CREATE INDEX idx_movies_rating   ON movies(rating DESC);

-- Showtime lookups: "shows for this movie, from today onward"
CREATE INDEX idx_shows_movie_date ON shows(movie_id, show_date);
CREATE INDEX idx_shows_screen     ON shows(screen_id);

-- Seat-map and booking-transaction hot path: "all seats for this show",
-- filtered by status during the lock/check step
CREATE INDEX idx_showseats_show_status ON show_seats(show_id, status);

-- Booking history / admin reports: "all bookings for this user",
-- "all bookings in date range", grouped by status
CREATE INDEX idx_bookings_user     ON bookings(user_id);
CREATE INDEX idx_bookings_show     ON bookings(show_id);
CREATE INDEX idx_bookings_status   ON bookings(status);
CREATE INDEX idx_bookings_created  ON bookings(created_at);

-- Payment reports: daily/monthly revenue, success/failure counts
CREATE INDEX idx_payments_status      ON payments(status);
CREATE INDEX idx_payments_created_at  ON payments(created_at);

-- Recommendation engine: genre lookups per movie/user, rating lookups
CREATE INDEX idx_moviegenres_genre    ON movie_genres(genre_id);
CREATE INDEX idx_userprefs_user       ON user_preferences(user_id);
CREATE INDEX idx_ratings_movie        ON movie_ratings(movie_id);
