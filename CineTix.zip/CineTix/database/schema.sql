-- =====================================================================
-- CineTix — MySQL 8.0 Database Schema
-- Demonstrates: PK/FK, 1:1 / 1:N / M:N relationships, NOT NULL, UNIQUE,
-- CHECK constraints, and 3NF-normalized table design.
-- Run order: schema.sql -> sample_data.sql -> views.sql -> indexes.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS cinetix CHARACTER SET utf8mb4;
USE cinetix;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS watch_history;
DROP TABLE IF EXISTS movie_ratings;
DROP TABLE IF EXISTS user_preferences;
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS booking_seats;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS show_seats;
DROP TABLE IF EXISTS shows;
DROP TABLE IF EXISTS seats;
DROP TABLE IF EXISTS screens;
DROP TABLE IF EXISTS theatres;
DROP TABLE IF EXISTS movie_genres;
DROP TABLE IF EXISTS genres;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS -------------------------------------------------------------
CREATE TABLE users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    email           VARCHAR(120) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(120) NOT NULL,
    phone           VARCHAR(20),
    is_admin        BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. GENRES --------------------------------------------------------------
CREATE TABLE genres (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    name    VARCHAR(50) NOT NULL UNIQUE
);

-- 3. MOVIES ----------------------------------------------------------------
CREATE TABLE movies (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    title               VARCHAR(150) NOT NULL,
    description         TEXT,
    language            VARCHAR(30)  NOT NULL,
    duration_minutes    INT NOT NULL,
    release_date        DATE NOT NULL,
    rating              DECIMAL(3,1) DEFAULT 0,
    poster_url          VARCHAR(255),
    status              VARCHAR(20) NOT NULL DEFAULT 'Available',
    CONSTRAINT ck_movie_rating_range CHECK (rating >= 0 AND rating <= 10),
    CONSTRAINT ck_duration_positive CHECK (duration_minutes > 0),
    CONSTRAINT ck_movie_status CHECK (status IN ('Available','Upcoming'))
);

-- 4. MOVIE_GENRES (resolves Movies <-> Genres, many-to-many) ---------------
CREATE TABLE movie_genres (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    movie_id    INT NOT NULL,
    genre_id    INT NOT NULL,
    CONSTRAINT fk_mg_movie FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    CONSTRAINT fk_mg_genre FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE CASCADE,
    CONSTRAINT uq_movie_genre UNIQUE (movie_id, genre_id)
);

-- 5. THEATRES ----------------------------------------------------------
CREATE TABLE theatres (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    location    VARCHAR(255) NOT NULL
);

-- 6. SCREENS (one theatre -> many screens) ------------------------------
CREATE TABLE screens (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    theatre_id      INT NOT NULL,
    name            VARCHAR(50) NOT NULL,
    total_seats     INT NOT NULL,
    CONSTRAINT fk_screen_theatre FOREIGN KEY (theatre_id) REFERENCES theatres(id) ON DELETE CASCADE
);

-- 7. SEATS (one screen -> many seats) ------------------------------------
CREATE TABLE seats (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    screen_id       INT NOT NULL,
    seat_number     VARCHAR(10) NOT NULL,
    seat_row        VARCHAR(5)  NOT NULL,
    seat_type       VARCHAR(20) NOT NULL DEFAULT 'Regular',
    CONSTRAINT fk_seat_screen FOREIGN KEY (screen_id) REFERENCES screens(id) ON DELETE CASCADE,
    CONSTRAINT uq_screen_seat UNIQUE (screen_id, seat_number),
    CONSTRAINT ck_seat_type CHECK (seat_type IN ('Regular','Premium'))
);

-- 8. SHOWS (one movie -> many shows; one screen -> many shows) -----------
CREATE TABLE shows (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    movie_id        INT NOT NULL,
    screen_id       INT NOT NULL,
    show_date       DATE NOT NULL,
    show_time       TIME NOT NULL,
    base_price      DECIMAL(8,2) NOT NULL,
    CONSTRAINT fk_show_movie  FOREIGN KEY (movie_id)  REFERENCES movies(id)  ON DELETE CASCADE,
    CONSTRAINT fk_show_screen FOREIGN KEY (screen_id) REFERENCES screens(id) ON DELETE CASCADE,
    CONSTRAINT ck_base_price_positive CHECK (base_price > 0)
);

-- 9. SHOW_SEATS (one show -> many seats; the bookable unit) --------------
CREATE TABLE show_seats (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    show_id     INT NOT NULL,
    seat_id     INT NOT NULL,
    status      VARCHAR(20) NOT NULL DEFAULT 'Available',
    price       DECIMAL(8,2) NOT NULL,
    CONSTRAINT fk_ss_show FOREIGN KEY (show_id) REFERENCES shows(id) ON DELETE CASCADE,
    CONSTRAINT fk_ss_seat FOREIGN KEY (seat_id) REFERENCES seats(id) ON DELETE CASCADE,
    CONSTRAINT uq_show_seat UNIQUE (show_id, seat_id),   -- prevents double-booking at the schema level
    CONSTRAINT ck_showseat_status CHECK (status IN ('Available','Locked','Booked'))
);

-- 10. BOOKINGS (one user -> many bookings) -------------------------------
CREATE TABLE bookings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    booking_code    VARCHAR(20) NOT NULL UNIQUE,
    user_id         INT NOT NULL,
    show_id         INT NOT NULL,
    total_amount    DECIMAL(8,2) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'Pending',
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_show FOREIGN KEY (show_id) REFERENCES shows(id) ON DELETE CASCADE,
    CONSTRAINT ck_booking_status CHECK (status IN ('Pending','Confirmed','Cancelled','Completed'))
);

-- 11. BOOKING_SEATS (one booking -> many seats, M:N resolved) ------------
CREATE TABLE booking_seats (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    booking_id      INT NOT NULL,
    show_seat_id    INT NOT NULL,
    CONSTRAINT fk_bs_booking   FOREIGN KEY (booking_id)   REFERENCES bookings(id)   ON DELETE CASCADE,
    CONSTRAINT fk_bs_showseat  FOREIGN KEY (show_seat_id) REFERENCES show_seats(id) ON DELETE CASCADE,
    CONSTRAINT uq_booking_showseat UNIQUE (booking_id, show_seat_id)
);

-- 12. PAYMENTS (one booking -> one payment, strict 1:1) ------------------
CREATE TABLE payments (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    booking_id      INT NOT NULL UNIQUE,
    transaction_id  VARCHAR(40) NOT NULL UNIQUE,
    amount          DECIMAL(8,2) NOT NULL,
    method          VARCHAR(30) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'Pending',
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    CONSTRAINT ck_payment_status CHECK (status IN ('Pending','Success','Failed','Refunded'))
);

-- 13. TICKETS (one booking -> one ticket, strict 1:1) ---------------------
CREATE TABLE tickets (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    booking_id      INT NOT NULL UNIQUE,
    ticket_code     VARCHAR(40) NOT NULL UNIQUE,
    qr_path         VARCHAR(255),
    issued_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ticket_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- 14. USER_PREFERENCES (Users <-> Genres, many-to-many) -------------------
CREATE TABLE user_preferences (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    genre_id    INT NOT NULL,
    CONSTRAINT fk_pref_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
    CONSTRAINT fk_pref_genre FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE CASCADE,
    CONSTRAINT uq_user_genre UNIQUE (user_id, genre_id)
);

-- 15. MOVIE_RATINGS (Users <-> Movies, many-to-many with an attribute) ----
CREATE TABLE movie_ratings (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    movie_id    INT NOT NULL,
    rating      INT NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rating_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
    CONSTRAINT fk_rating_movie FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    CONSTRAINT uq_user_movie_rating UNIQUE (user_id, movie_id),
    CONSTRAINT ck_rating_range CHECK (rating BETWEEN 1 AND 5)
);

-- 16. WATCH_HISTORY (Users <-> Movies, many-to-many) ----------------------
CREATE TABLE watch_history (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    movie_id    INT NOT NULL,
    watched_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_history_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
    CONSTRAINT fk_history_movie FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

-- =====================================================================
-- Relationship summary
-- =====================================================================
-- Users (1) ----< Bookings (N)                       one-to-many
-- Movies (1) ----< Shows (N)                         one-to-many
-- Theatres (1) ----< Screens (N)                     one-to-many
-- Screens (1) ----< Seats (N)                        one-to-many
-- Shows (1) ----< Show_Seats (N)                     one-to-many
-- Bookings (1) ----< Booking_Seats (N)                one-to-many
-- Bookings (1) ---- Payments (1)                      one-to-one
-- Bookings (1) ---- Tickets (1)                       one-to-one
-- Movies (M) ----< Movie_Genres >---- Genres (N)      many-to-many
-- Users (M) ----< User_Preferences >---- Genres (N)   many-to-many
-- Users (M) ----< Movie_Ratings >---- Movies (N)      many-to-many (+attribute)
-- Users (M) ----< Watch_History >---- Movies (N)      many-to-many
-- =====================================================================

-- =====================================================================
-- Normalization note (1NF / 2NF / 3NF)
-- =====================================================================
-- 1NF: every column holds a single atomic value (e.g. a movie's genres are
--      not stored as a comma-separated string -- they live in the separate
--      movie_genres table, one genre per row).
-- 2NF: every table has a single-column surrogate key (id) and every
--      non-key column depends on that whole key; junction tables such as
--      movie_genres carry no data of their own beyond the two FKs, so
--      there is no partial dependency on part of a composite key.
-- 3NF: no non-key column depends on another non-key column. For example,
--      show_seats.price is stored per show+seat (prices can change show to
--      show) rather than being derived by joining seats.seat_type back to a
--      price list inside shows -- but it is still the "price actually paid
--      for this bookable unit," not duplicated with seats.seat_type, so
--      there is no transitive dependency.
-- =====================================================================
