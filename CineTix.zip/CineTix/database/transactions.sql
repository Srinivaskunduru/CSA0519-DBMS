-- =====================================================================
-- CineTix — Transactions, COMMIT / ROLLBACK, ACID demonstration
--
-- This is the raw-SQL form of exactly what services/booking_service.py
-- does through the ORM for every real booking in the running app:
-- lock the seats, create the booking, record payment, and only then
-- mark seats Booked -- or roll everything back if payment fails.
-- =====================================================================
USE cinetix;

-- -----------------------------------------------------------------
-- Scenario A: Successful booking (2 seats, show_id = 1)
-- -----------------------------------------------------------------
START TRANSACTION;

-- 1. Check + lock the requested seats so no other transaction can
--    grab them until this one commits or rolls back (Isolation).
SELECT id, status FROM show_seats
WHERE show_id = 1 AND seat_id IN (
  SELECT id FROM seats WHERE screen_id = 1 AND seat_number IN ('C3','C4')
)
FOR UPDATE;

-- 2. Mark them Locked while payment is processed
UPDATE show_seats
SET status = 'Locked'
WHERE show_id = 1 AND seat_id IN (
  SELECT id FROM seats WHERE screen_id = 1 AND seat_number IN ('C3','C4')
) AND status = 'Available';

-- 3. Create the booking (Pending) and its seat rows
INSERT INTO bookings (booking_code, user_id, show_id, total_amount, status)
VALUES ('BKGDEMOTXN01', 2, 1, 360.00, 'Pending');

SET @new_booking_id = LAST_INSERT_ID();

INSERT INTO booking_seats (booking_id, show_seat_id)
SELECT @new_booking_id, ss.id
FROM show_seats ss JOIN seats se ON se.id = ss.seat_id
WHERE ss.show_id = 1 AND se.seat_number IN ('C3','C4');

-- 4. Simulated payment gateway says SUCCESS
INSERT INTO payments (booking_id, transaction_id, amount, method, status)
VALUES (@new_booking_id, 'TXNDEMO0001', 360.00, 'Card', 'Success');

-- 5. Only now do seats become permanently Booked and the booking Confirmed
UPDATE show_seats
SET status = 'Booked'
WHERE show_id = 1 AND seat_id IN (
  SELECT id FROM seats WHERE screen_id = 1 AND seat_number IN ('C3','C4')
);

UPDATE bookings SET status = 'Confirmed' WHERE id = @new_booking_id;

-- Atomicity + Durability: either every statement above lands, or none do.
COMMIT;


-- -----------------------------------------------------------------
-- Scenario B: Failed payment -> ROLLBACK (seats must NOT stay booked)
-- -----------------------------------------------------------------
START TRANSACTION;

UPDATE show_seats
SET status = 'Locked'
WHERE show_id = 1 AND seat_id IN (
  SELECT id FROM seats WHERE screen_id = 1 AND seat_number IN ('C5','C6')
) AND status = 'Available';

INSERT INTO bookings (booking_code, user_id, show_id, total_amount, status)
VALUES ('BKGDEMOFAIL1', 2, 1, 360.00, 'Pending');

SET @failed_booking_id = LAST_INSERT_ID();

INSERT INTO booking_seats (booking_id, show_seat_id)
SELECT @failed_booking_id, ss.id
FROM show_seats ss JOIN seats se ON se.id = ss.seat_id
WHERE ss.show_id = 1 AND se.seat_number IN ('C5','C6');

-- Simulated payment gateway says FAILED -- undo everything in this
-- transaction. The seats go straight back to how they were; nothing
-- about this attempt is left in a half-finished state (Consistency).
ROLLBACK;

-- After ROLLBACK, re-running:
--   SELECT status FROM show_seats WHERE show_id = 1
--   AND seat_id IN (SELECT id FROM seats WHERE seat_number IN ('C5','C6'));
-- will show 'Available' again, and the booking row from this block
-- never existed as far as any other session is concerned.
