-- =====================================================================
-- CineTix — Sample data (run after schema.sql)
-- Demonstrates SQL DML: INSERT statements seeding every table.
-- (The running web app seeds itself via seed.py / `flask seed-db` with
--  equivalent data through the ORM -- this file is the raw-SQL version
--  for direct demonstration in MySQL Workbench.)
-- =====================================================================
USE cinetix;

-- Users (password_hash values below are placeholders -- the real app
-- always hashes with Werkzeug's generate_password_hash(), never plaintext)
INSERT INTO users (username, email, password_hash, full_name, phone, is_admin) VALUES
('admin', 'admin@cinetix.com', 'scrypt$placeholder-hash-admin', 'CineTix Admin', '9000000001', TRUE),
('demo',  'demo@cinetix.com',  'scrypt$placeholder-hash-demo',  'Demo User',      '9000000002', FALSE),
('asha',  'asha@cinetix.com',  'scrypt$placeholder-hash-asha',  'Asha Verma',     '9000000003', FALSE);

INSERT INTO genres (name) VALUES
('Action'), ('Drama'), ('Comedy'), ('Sci-Fi'), ('Thriller'), ('Romance'), ('Animation');

INSERT INTO movies (title, description, language, duration_minutes, release_date, rating, poster_url, status) VALUES
('Edge of Tomorrow City', 'A detective races to stop a time-looping heist.', 'English', 128, '2026-11-10', 8.4, '/static/images/posters/p1.jpg', 'Available'),
('Monsoon Letters', 'Two strangers exchange letters across a city.', 'Hindi', 142, '2026-11-01', 7.9, '/static/images/posters/p2.jpg', 'Available'),
('Silent Orbit', 'A space station crew uncovers a conspiracy.', 'English', 135, '2026-11-18', 8.1, '/static/images/posters/p3.jpg', 'Available'),
('Red Alley', 'A tense cat-and-mouse thriller.', 'English', 118, '2026-12-10', 0.0, '/static/images/posters/p4.jpg', 'Upcoming');

INSERT INTO movie_genres (movie_id, genre_id) VALUES
(1, 1), (1, 4),
(2, 2), (2, 6),
(3, 4), (3, 5),
(4, 5), (4, 1);

INSERT INTO theatres (name, location) VALUES
('CineTix Grand Mall', 'MG Road, Downtown'),
('CineTix Riverside', 'Riverside Avenue');

INSERT INTO screens (theatre_id, name, total_seats) VALUES
(1, 'Screen 1', 60),
(1, 'Screen 2', 60),
(2, 'Screen 1', 60);

-- 6 rows (A-F) x 10 seats on Screen 1 of Grand Mall, rows A-B Premium
INSERT INTO seats (screen_id, seat_number, seat_row, seat_type)
SELECT 1, CONCAT(r.row_letter, n.num), r.row_letter,
       IF(r.row_letter IN ('A','B'), 'Premium', 'Regular')
FROM (SELECT 'A' row_letter UNION SELECT 'B' UNION SELECT 'C'
      UNION SELECT 'D' UNION SELECT 'E' UNION SELECT 'F') r
CROSS JOIN (SELECT 1 num UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5
            UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10) n;

INSERT INTO shows (movie_id, screen_id, show_date, show_time, base_price) VALUES
(1, 1, CURDATE(), '18:30:00', 180.00),
(2, 1, CURDATE(), '21:45:00', 180.00),
(3, 2, CURDATE() + INTERVAL 1 DAY, '14:00:00', 180.00);

-- One row per seat for show 1, Regular=180, Premium=280
INSERT INTO show_seats (show_id, seat_id, status, price)
SELECT 1, s.id, 'Available', IF(s.seat_type = 'Premium', 280.00, 180.00)
FROM seats s WHERE s.screen_id = 1;

INSERT INTO user_preferences (user_id, genre_id) VALUES (2, 1), (2, 4), (3, 2), (3, 6);

INSERT INTO movie_ratings (user_id, movie_id, rating) VALUES (2, 1, 5), (3, 2, 4);

INSERT INTO watch_history (user_id, movie_id) VALUES (2, 1), (3, 2);

-- A sample confirmed booking end-to-end, for demonstrating JOIN/reports queries
INSERT INTO bookings (booking_code, user_id, show_id, total_amount, status) VALUES
('BKGSAMPLE01', 2, 1, 360.00, 'Confirmed');

UPDATE show_seats SET status = 'Booked' WHERE show_id = 1 AND seat_id IN (
  SELECT id FROM seats WHERE screen_id = 1 AND seat_number IN ('A1','A2')
);

INSERT INTO booking_seats (booking_id, show_seat_id)
SELECT 1, ss.id FROM show_seats ss
JOIN seats se ON se.id = ss.seat_id
WHERE ss.show_id = 1 AND se.seat_number IN ('A1','A2');

INSERT INTO payments (booking_id, transaction_id, amount, method, status) VALUES
(1, 'TXNSAMPLE0001', 360.00, 'Card', 'Success');

INSERT INTO tickets (booking_id, ticket_code, qr_path) VALUES
(1, 'TKTSAMPLE0001', 'qrcodes/TKTSAMPLE0001.png');
