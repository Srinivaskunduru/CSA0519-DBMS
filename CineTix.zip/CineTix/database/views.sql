-- =====================================================================
-- CineTix — Views
-- Demonstrates: VIEWS, JOIN, GROUP BY, aggregate functions
-- =====================================================================
USE cinetix;

-- A single view that flattens a confirmed booking into everything needed
-- to print or re-display a ticket, so application code never has to
-- hand-write this 6-table join more than once.
CREATE OR REPLACE VIEW vw_booking_details AS
SELECT
    b.id                 AS booking_id,
    b.booking_code,
    u.username,
    u.full_name,
    m.title              AS movie_title,
    t.name               AS theatre_name,
    sc.name              AS screen_name,
    sh.show_date,
    sh.show_time,
    GROUP_CONCAT(se.seat_number ORDER BY se.seat_number SEPARATOR ', ') AS seats,
    b.total_amount,
    b.status             AS booking_status,
    p.status              AS payment_status,
    p.transaction_id
FROM bookings b
JOIN users u          ON u.id = b.user_id
JOIN shows sh          ON sh.id = b.show_id
JOIN movies m          ON m.id = sh.movie_id
JOIN screens sc        ON sc.id = sh.screen_id
JOIN theatres t        ON t.id = sc.theatre_id
JOIN booking_seats bs  ON bs.booking_id = b.id
JOIN show_seats ss     ON ss.id = bs.show_seat_id
JOIN seats se          ON se.id = ss.seat_id
LEFT JOIN payments p   ON p.booking_id = b.id
GROUP BY b.id, u.username, u.full_name, m.title, t.name, sc.name,
         sh.show_date, sh.show_time, b.total_amount, b.status, p.status, p.transaction_id;

-- A view used directly by the admin "most booked movies" report.
CREATE OR REPLACE VIEW vw_movie_booking_counts AS
SELECT
    m.id               AS movie_id,
    m.title,
    COUNT(b.id)        AS total_bookings,
    SUM(b.total_amount) AS total_revenue
FROM movies m
JOIN shows sh    ON sh.movie_id = m.id
JOIN bookings b  ON b.show_id = sh.id AND b.status = 'Confirmed'
GROUP BY m.id, m.title;

-- A view of current seat availability per show, used by the seat map.
CREATE OR REPLACE VIEW vw_show_seat_availability AS
SELECT
    sh.id AS show_id,
    COUNT(*)                                       AS total_seats,
    SUM(ss.status = 'Available')                   AS available_seats,
    SUM(ss.status = 'Booked')                      AS booked_seats,
    SUM(ss.status = 'Locked')                      AS locked_seats
FROM shows sh
JOIN show_seats ss ON ss.show_id = sh.id
GROUP BY sh.id;
