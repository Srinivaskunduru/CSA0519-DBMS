-- =====================================================================
-- CineTix — Reporting Queries
-- Demonstrates: JOIN (INNER/LEFT), GROUP BY, HAVING, COUNT/SUM/AVG,
-- subqueries. These are the raw-SQL equivalents of every number shown
-- on the admin dashboard (routes/admin.py runs the SQLAlchemy versions).
-- =====================================================================
USE cinetix;

-- 1. Total registered users, movies, theatres, bookings (simple COUNTs)
SELECT (SELECT COUNT(*) FROM users WHERE is_admin = FALSE)   AS total_users,
       (SELECT COUNT(*) FROM movies)                          AS total_movies,
       (SELECT COUNT(*) FROM theatres)                        AS total_theatres,
       (SELECT COUNT(*) FROM bookings)                        AS total_bookings;

-- 2. Successful vs failed payments, and total revenue
SELECT status, COUNT(*) AS num_payments, SUM(amount) AS total_amount
FROM payments
GROUP BY status;

-- 3. Most booked movies (INNER JOIN + GROUP BY + COUNT, ordered)
SELECT m.title, COUNT(b.id) AS times_booked
FROM movies m
JOIN shows sh   ON sh.movie_id = m.id
JOIN bookings b ON b.show_id = sh.id AND b.status = 'Confirmed'
GROUP BY m.id, m.title
ORDER BY times_booked DESC
LIMIT 5;

-- 4. Most popular genres (JOIN across the movie_genres bridge table)
SELECT g.name, COUNT(b.id) AS bookings_in_genre
FROM genres g
JOIN movie_genres mg ON mg.genre_id = g.id
JOIN shows sh        ON sh.movie_id = mg.movie_id
JOIN bookings b      ON b.show_id = sh.id AND b.status = 'Confirmed'
GROUP BY g.id, g.name
ORDER BY bookings_in_genre DESC
LIMIT 5;

-- 5. Theatre-wise bookings
SELECT t.name AS theatre, COUNT(b.id) AS bookings
FROM theatres t
JOIN screens sc  ON sc.theatre_id = t.id
JOIN shows sh    ON sh.screen_id = sc.id
JOIN bookings b  ON b.show_id = sh.id AND b.status = 'Confirmed'
GROUP BY t.id, t.name
ORDER BY bookings DESC;

-- 6. Daily revenue, last 30 days
SELECT DATE(p.created_at) AS day, SUM(p.amount) AS revenue
FROM payments p
WHERE p.status = 'Success' AND p.created_at >= CURDATE() - INTERVAL 30 DAY
GROUP BY DATE(p.created_at)
ORDER BY day;

-- 7. Monthly revenue (MySQL DATE_FORMAT)
SELECT DATE_FORMAT(p.created_at, '%Y-%m') AS month, SUM(p.amount) AS revenue
FROM payments p
WHERE p.status = 'Success'
GROUP BY month
ORDER BY month;

-- 8. HAVING example: theatres that have hosted more than 10 confirmed bookings
SELECT t.name, COUNT(b.id) AS bookings
FROM theatres t
JOIN screens sc ON sc.theatre_id = t.id
JOIN shows sh   ON sh.screen_id = sc.id
JOIN bookings b ON b.show_id = sh.id AND b.status = 'Confirmed'
GROUP BY t.id, t.name
HAVING COUNT(b.id) > 10;

-- 9. Average rating per movie, including movies with zero ratings
--    (LEFT JOIN so unrated movies still appear, with NULL/0 average)
SELECT m.title, ROUND(AVG(mr.rating), 2) AS avg_user_rating, COUNT(mr.id) AS num_ratings
FROM movies m
LEFT JOIN movie_ratings mr ON mr.movie_id = m.id
GROUP BY m.id, m.title
ORDER BY avg_user_rating DESC;

-- 10. Subquery example: users who have never completed a booking
SELECT u.username, u.full_name
FROM users u
WHERE u.is_admin = FALSE
  AND u.id NOT IN (SELECT DISTINCT user_id FROM bookings WHERE status = 'Confirmed');

-- 11. Subquery example: shows that are more than 80% sold out
SELECT sh.id AS show_id, m.title, sh.show_date, sh.show_time,
       (SELECT COUNT(*) FROM show_seats ss WHERE ss.show_id = sh.id AND ss.status = 'Booked') AS booked,
       (SELECT COUNT(*) FROM show_seats ss WHERE ss.show_id = sh.id) AS total
FROM shows sh
JOIN movies m ON m.id = sh.movie_id
WHERE (SELECT COUNT(*) FROM show_seats ss WHERE ss.show_id = sh.id AND ss.status = 'Booked')
      / (SELECT COUNT(*) FROM show_seats ss WHERE ss.show_id = sh.id) > 0.8;
