"""
Seeds the database with demo data: an admin account, a demo user, genres,
movies, a theatre with two screens, and a handful of shows over the next
few days. Run with:

    python seed.py

or, once the app is created:

    flask --app app.py seed-db
"""
from datetime import date, time, timedelta

from models import db, User, Genre, Movie, MovieGenre, Theatre, Screen, Seat, Show, ShowSeat


def run_seed(app):
    with app.app_context():
        db.create_all()

        if User.query.filter_by(username="admin").first():
            print("Database already seeded -- skipping.")
            return

        # --- Users ---
        admin = User(username="admin", email="admin@cinetix.com", full_name="CineTix Admin", is_admin=True)
        admin.set_password("admin123")
        demo = User(username="demo", email="demo@cinetix.com", full_name="Demo User", phone="9000000000")
        demo.set_password("demo123")
        db.session.add_all([admin, demo])

        # --- Genres ---
        genre_names = ["Action", "Drama", "Comedy", "Sci-Fi", "Thriller", "Romance", "Animation"]
        genres = {name: Genre(name=name) for name in genre_names}
        db.session.add_all(genres.values())
        db.session.flush()

        # --- Movies ---
        movies_data = [
            ("Edge of Tomorrow City", "A detective races to stop a time-looping heist in a neon megacity.",
             "English", 128, date.today() - timedelta(days=10), 8.4, "Action", "Sci-Fi"),
            ("Monsoon Letters", "Two strangers exchange letters across a city during monsoon season.",
             "Hindi", 142, date.today() - timedelta(days=20), 7.9, "Drama", "Romance"),
            ("The Last Laugh Society", "A washed-up comedian starts an underground comedy club.",
             "English", 110, date.today() - timedelta(days=5), 7.2, "Comedy", "Drama"),
            ("Silent Orbit", "A space station crew uncovers a conspiracy that threatens Earth.",
             "English", 135, date.today() - timedelta(days=2), 8.1, "Sci-Fi", "Thriller"),
            ("Paper Boats", "An animated tale of a village girl who sails paper boats to find her father.",
             "Tamil", 98, date.today() - timedelta(days=15), 8.6, "Animation", "Drama"),
            ("Red Alley", "A tense cat-and-mouse thriller set across one night in an old city alley.",
             "English", 118, date.today() + timedelta(days=15), 0, "Thriller", "Action"),
            ("Second Innings", "A retired athlete is pulled back for one last tournament.",
             "Hindi", 132, date.today() + timedelta(days=25), 0, "Drama", "Comedy"),
        ]
        movies = []
        for title, desc, lang, dur, rel, rating, g1, g2 in movies_data:
            status = "Upcoming" if rel > date.today() else "Available"
            m = Movie(title=title, description=desc, language=lang, duration_minutes=dur,
                      release_date=rel, rating=rating, status=status,
                      poster_url=f"https://picsum.photos/seed/{title.replace(' ', '')}/400/600")
            db.session.add(m)
            db.session.flush()
            db.session.add(MovieGenre(movie_id=m.id, genre_id=genres[g1].id))
            db.session.add(MovieGenre(movie_id=m.id, genre_id=genres[g2].id))
            movies.append(m)

        # --- Theatre / Screens / Seats ---
        theatre1 = Theatre(name="CineTix Grand Mall", location="MG Road, Downtown")
        theatre2 = Theatre(name="CineTix Riverside", location="Riverside Avenue")
        db.session.add_all([theatre1, theatre2])
        db.session.flush()

        def build_screen(theatre, name, rows=6, seats_per_row=10, premium_rows=2):
            screen = Screen(theatre_id=theatre.id, name=name, total_seats=rows * seats_per_row)
            db.session.add(screen)
            db.session.flush()
            for r in range(rows):
                row_letter = chr(ord("A") + r)
                seat_type = "Premium" if r < premium_rows else "Regular"
                for n in range(1, seats_per_row + 1):
                    db.session.add(Seat(screen_id=screen.id, seat_number=f"{row_letter}{n}",
                                         seat_row=row_letter, seat_type=seat_type))
            db.session.flush()
            return screen

        screen1 = build_screen(theatre1, "Screen 1")
        screen2 = build_screen(theatre1, "Screen 2")
        screen3 = build_screen(theatre2, "Screen 1")

        # --- Shows over the next 5 days ---
        available_movies = [m for m in movies if m.status == "Available"]
        screens = [screen1, screen2, screen3]
        showtimes = [time(10, 30), time(14, 0), time(18, 30), time(21, 45)]

        for day_offset in range(5):
            show_date = date.today() + timedelta(days=day_offset)
            for i, movie in enumerate(available_movies):
                screen = screens[i % len(screens)]
                show_time = showtimes[i % len(showtimes)]
                show = Show(movie_id=movie.id, screen_id=screen.id, show_date=show_date,
                            show_time=show_time, base_price=180.0)
                db.session.add(show)
                db.session.flush()
                for seat in Seat.query.filter_by(screen_id=screen.id).all():
                    price = 280.0 if seat.seat_type == "Premium" else 180.0
                    db.session.add(ShowSeat(show_id=show.id, seat_id=seat.id,
                                             status="Available", price=price))

        db.session.commit()
        print("Seed complete.")
        print("  Admin login: admin / admin123")
        print("  Demo login:  demo  / demo123")


if __name__ == "__main__":
    from app import app
    run_seed(app)
