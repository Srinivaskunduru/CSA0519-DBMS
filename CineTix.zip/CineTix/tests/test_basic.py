"""
Smoke tests for CineTix. Run with:  python -m pytest tests/ -v
Uses an in-memory SQLite database so it never touches cinetix.db.
"""
import os
import sys
from datetime import date, time, timedelta

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ.pop("MYSQL_HOST", None)  # force SQLite for tests

from app import create_app
from config import Config
from models import db, User, Genre, Movie, MovieGenre, Theatre, Screen, Seat, Show, ShowSeat
from services.booking_service import create_booking_and_charge, BookingError


class TestConfig(Config):
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    TESTING = True
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        _seed_minimal()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def _seed_minimal():
    user = User(username="tester", email="tester@example.com", full_name="Tester")
    user.set_password("pass1234")
    db.session.add(user)

    genre = Genre(name="Action")
    db.session.add(genre)
    db.session.flush()

    movie = Movie(title="Test Movie", language="English", duration_minutes=100,
                  release_date=date.today(), rating=7.5, status="Available")
    db.session.add(movie)
    db.session.flush()
    db.session.add(MovieGenre(movie_id=movie.id, genre_id=genre.id))

    theatre = Theatre(name="Test Theatre", location="Nowhere")
    db.session.add(theatre)
    db.session.flush()

    screen = Screen(theatre_id=theatre.id, name="Screen 1", total_seats=4)
    db.session.add(screen)
    db.session.flush()

    for n in range(1, 5):
        db.session.add(Seat(screen_id=screen.id, seat_number=f"A{n}", seat_row="A"))
    db.session.flush()

    show = Show(movie_id=movie.id, screen_id=screen.id,
                show_date=date.today() + timedelta(days=1), show_time=time(18, 0),
                base_price=200.0)
    db.session.add(show)
    db.session.flush()

    for seat in Seat.query.filter_by(screen_id=screen.id).all():
        db.session.add(ShowSeat(show_id=show.id, seat_id=seat.id, status="Available", price=200.0))

    db.session.commit()


def test_home_page_loads(client):
    resp = client.get("/")
    assert resp.status_code == 200


def test_movie_listing_loads(client):
    resp = client.get("/movies")
    assert resp.status_code == 200
    assert b"Test Movie" in resp.data


def test_successful_booking_books_seats_and_issues_ticket(app):
    with app.app_context():
        user = User.query.filter_by(username="tester").first()
        show = Show.query.first()
        seat_ids = [s.id for s in ShowSeat.query.filter_by(show_id=show.id).limit(2).all()]

        booking, payment = create_booking_and_charge(
            user_id=user.id, show_id=show.id, show_seat_ids=seat_ids,
            payment_method="Card", card_outcome="auto",
        )

        assert booking.status == "Confirmed"
        assert payment.status == "Success"
        assert booking.ticket is not None
        for sid in seat_ids:
            assert ShowSeat.query.get(sid).status == "Booked"


def test_failed_payment_rolls_back_and_releases_seats(app):
    with app.app_context():
        user = User.query.filter_by(username="tester").first()
        show = Show.query.first()
        seat_ids = [s.id for s in ShowSeat.query.filter_by(show_id=show.id, status="Available").limit(2).all()]

        with pytest.raises(BookingError):
            create_booking_and_charge(
                user_id=user.id, show_id=show.id, show_seat_ids=seat_ids,
                payment_method="Card", card_outcome="force_fail",
            )

        for sid in seat_ids:
            assert ShowSeat.query.get(sid).status == "Available"


def test_cannot_double_book_the_same_seat(app):
    with app.app_context():
        user = User.query.filter_by(username="tester").first()
        show = Show.query.first()
        seat_ids = [ShowSeat.query.filter_by(show_id=show.id).first().id]

        create_booking_and_charge(user_id=user.id, show_id=show.id,
                                   show_seat_ids=seat_ids, payment_method="Card")

        with pytest.raises(BookingError):
            create_booking_and_charge(user_id=user.id, show_id=show.id,
                                       show_seat_ids=seat_ids, payment_method="Card")
